#!/usr/bin/env python3
import spidev, RPi.GPIO as GPIO, time, sys

# ---- Board pins → BCM ----
CS_PIN  = 17   # Board Pin 11 (manual CS)
INT_PIN = 27   # Board Pin 13

# ---- MCP2515 SPI commands / registers ----
CMD_RESET       = 0xC0
CMD_READ        = 0x03
CMD_WRITE       = 0x02
CMD_BIT_MODIFY  = 0x05
CMD_READ_RX0    = 0x90
CMD_READ_RX1    = 0x94

REG_CANCTRL  = 0x0F
REG_CANSTAT  = 0x0E
REG_CNF1     = 0x2A
REG_CNF2     = 0x29
REG_CNF3     = 0x28
REG_CANINTE  = 0x2B
REG_CANINTF  = 0x2C
REG_RXB0CTRL = 0x60
REG_RXB1CTRL = 0x70

OPMODE_CONFIG = 0x80
OPMODE_NORMAL = 0x00

def cs_low():  GPIO.output(CS_PIN, GPIO.LOW)
def cs_high(): GPIO.output(CS_PIN, GPIO.HIGH)

def spi_wr(b):
    return spi.xfer2(list(b))

def mcp_reset():
    cs_low(); spi_wr([CMD_RESET]); cs_high(); time.sleep(0.01)

def mcp_write(reg, *vals):
    cs_low(); spi_wr([CMD_WRITE, reg] + list(vals)); cs_high()

def mcp_read(reg, n=1):
    cs_low(); spi_wr([CMD_READ, reg])
    out = spi.xfer2([0x00]*n)
    cs_high()
    return out if n > 1 else out[0]

def mcp_bit_modify(reg, mask, data):
    cs_low(); spi_wr([CMD_BIT_MODIFY, reg, mask, data]); cs_high()

def set_opmode(mode):
    mcp_bit_modify(REG_CANCTRL, 0xE0, mode)
    for _ in range(100):
        if (mcp_read(REG_CANSTAT) & 0xE0) == mode:
            return True
        time.sleep(0.001)
    return False

def set_bitrate_500k_8mhz():
    # 500 kbps @ 8 MHz (matches your Pico setup)
    mcp_write(REG_CNF1, 0x00)
    mcp_write(REG_CNF2, 0x90)
    mcp_write(REG_CNF3, 0x02)

def accept_all():
    # Accept any frame, enable rollover, enable RX interrupts
    mcp_write(REG_RXB0CTRL, 0b01100100)  # RXM=11, BUKT=1
    mcp_write(REG_RXB1CTRL, 0b01100000)  # RXM=11
    mcp_write(REG_CANINTE,  0b00000011)  # RX0IE + RX1IE
    mcp_bit_modify(REG_CANINTF, 0xFF, 0x00)

def read_rxbuf(buf_index):
    cmd = CMD_READ_RX0 if buf_index == 0 else CMD_READ_RX1
    cs_low()
    spi_wr([cmd])
    sidh, sidl, eid8, eid0, dlc = spi.xfer2([0,0,0,0,0])
    dlc &= 0x0F
    data = bytes(spi.xfer2([0]*dlc)) if dlc else b""
    cs_high()
    can_id = ((sidh << 3) | (sidl >> 5)) & 0x7FF
    return can_id, data

def setup():
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)
    GPIO.setup(CS_PIN,  GPIO.OUT, initial=GPIO.HIGH)
    GPIO.setup(INT_PIN, GPIO.IN, pull_up_down=GPIO.PUD_UP)

    global spi
    spi = spidev.SpiDev()
    spi.open(0, 0)           # SPI0
    spi.max_speed_hz = 1000000
    spi.mode = 0
    spi.no_cs = True         # we drive CS manually on GPIO17

    mcp_reset()
    if not set_opmode(OPMODE_CONFIG):
        print("ERROR: can't enter CONFIG mode"); sys.exit(1)
    set_bitrate_500k_8mhz()
    accept_all()
    if not set_opmode(OPMODE_NORMAL):
        print("ERROR: can't enter NORMAL mode"); sys.exit(1)

def loop():
    print("Listening (manual CS) @500k, MCP2515 8MHz. Ctrl+C to exit.")
    try:
        while True:
            # Poll CANINTF flags (reliable, no edge issues)
            flags = mcp_read(REG_CANINTF)
            if flags & 0x01:  # RX0IF
                can_id, data = read_rxbuf(0)
                mcp_bit_modify(REG_CANINTF, 0x01, 0x00)
                handle(can_id, data)
            if flags & 0x02:  # RX1IF
                can_id, data = read_rxbuf(1)
                mcp_bit_modify(REG_CANINTF, 0x02, 0x00)
                handle(can_id, data)
            time.sleep(0.001)
    except KeyboardInterrupt:
        pass
    finally:
        spi.close()
        GPIO.cleanup()

def handle(can_id, data):
    if can_id == 0x100 and len(data) >= 1:
        print(f"ID=0x100 brightness={data[0]}")
    else:
        print(f"ID=0x{can_id:03X} data={data.hex()}")

if __name__ == "__main__":
    setup()
    loop()
