#!/usr/bin/env python3
# Raspberry Pi 4B -> MCP2515 (8 MHz) -> CAN sender
# Board pins used: MISO=21, MOSI=19, SCLK=23, CS=11(GPIO17, manual), INT=13(GPIO27)
# Sends ID 0x100 with 1-byte payload (0..255) to control Pico LED brightness.
# Matches the Pico receiver that expects 500 kbps and ID 0x100 (1 byte).

import time
import spidev
import RPi.GPIO as GPIO

# --- MCP2515 SPI commands & registers ---
CMD_RESET       = 0xC0
CMD_READ        = 0x03
CMD_WRITE       = 0x02
CMD_BIT_MODIFY  = 0x05
CMD_READ_STATUS = 0xA0
CMD_RTS_TXB0    = 0x81

REG_CANCTRL = 0x0F
REG_CANSTAT = 0x0E
REG_CNF1    = 0x2A
REG_CNF2    = 0x29
REG_CNF3    = 0x28
REG_TXB0CTRL= 0x30
REG_TXB0SIDH= 0x31
REG_TXB0SIDL= 0x32
REG_TXB0DLC = 0x35
REG_TXB0D0  = 0x36

OPMODE_CONFIG  = 0x80
OPMODE_NORMAL  = 0x00

# --- GPIO (manual CS and optional INT) ---
PIN_CS  = 17  # board pin 11
PIN_INT = 27  # board pin 13 (not strictly needed for TX)

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(PIN_CS, GPIO.OUT, initial=GPIO.HIGH)
GPIO.setup(PIN_INT, GPIO.IN)

# --- SPI setup (bus 0, device 0), manual CS ---
spi = spidev.SpiDev()
spi.open(0, 0)
spi.max_speed_hz = 1_000_000
spi.mode = 0
spi.no_cs = True   # because CS is manual on GPIO17

def cs_low():  GPIO.output(PIN_CS, GPIO.LOW)
def cs_high(): GPIO.output(PIN_CS, GPIO.HIGH)

def spi_write(bytes_out):
    cs_low()
    spi.xfer2(bytes_out)
    cs_high()

def reg_write(addr, *vals):
    cs_low()
    spi.xfer2([CMD_WRITE, addr] + list(vals))
    cs_high()

def reg_read(addr, n=1):
    cs_low()
    spi.xfer2([CMD_READ, addr])
    data = spi.readbytes(n)
    cs_high()
    return data if n > 1 else data[0]

def bit_modify(addr, mask, data):
    cs_low()
    spi.xfer2([CMD_BIT_MODIFY, addr, mask, data])
    cs_high()

def reset():
    spi_write([CMD_RESET])
    time.sleep(0.01)

def set_opmode(mode):
    bit_modify(REG_CANCTRL, 0xE0, mode)
    for _ in range(50):
        if (reg_read(REG_CANSTAT) & 0xE0) == mode:
            return True
        time.sleep(0.001)
    return False

def set_bitrate_500k_8mhz():
    # Same timing as your Pico receiver: CNF1=0x00, CNF2=0x90, CNF3=0x02
    reg_write(REG_CNF1, 0x00)
    reg_write(REG_CNF2, 0x90)
    reg_write(REG_CNF3, 0x02)

def mcp_init():
    reset()
    if not set_opmode(OPMODE_CONFIG):
        raise RuntimeError("Failed to enter CONFIG mode")
    set_bitrate_500k_8mhz()
    if not set_opmode(OPMODE_NORMAL):
        raise RuntimeError("Failed to enter NORMAL mode")

def send_std_frame(id11, data_bytes):
    """Send a standard (11-bit) CAN frame on TXB0."""
    id11 &= 0x7FF
    sidh = (id11 >> 3) & 0xFF
    sidl = (id11 & 0x07) << 5
    dlc  = len(data_bytes) & 0x0F

    # Load TXB0 registers
    reg_write(REG_TXB0SIDH, sidh)
    reg_write(REG_TXB0SIDL, sidl)
    reg_write(REG_TXB0DLC, dlc)
    if dlc:
        reg_write(REG_TXB0D0, *list(data_bytes))

    # Request to send TXB0
    spi_write([CMD_RTS_TXB0])

    # Optional: wait for TX to clear TXREQ bit (bit3 of TXB0CTRL)
    for _ in range(100):
        txb0ctrl = reg_read(REG_TXB0CTRL)
        if (txb0ctrl & 0x08) == 0:
            return True
        time.sleep(0.001)
    return False

def main():
    try:
        mcp_init()
        print("CAN sender ready @ 500 kbps, ID 0x100; ramp brightness 0..255..0")

        # Generate 0..255..0 ramp forever
        up = True
        b  = 0
        while True:
            ok = send_std_frame(0x100, bytes([b]))
            if ok:
                print(f"TX -> 0x100 : {b}")
            else:
                print("WARN: TX timeout (no TX complete)")

            # Next value
            if up:
                b += 5
                if b >= 255:
                    b = 255
                    up = False
            else:
                b -= 5
                if b <= 0:
                    b = 0
                    up = True

            time.sleep(0.05)  # ~20 msgs/sec
    finally:
        spi.close()
        GPIO.cleanup()

if __name__ == "__main__":
    main()
